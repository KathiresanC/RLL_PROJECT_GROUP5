package com.G5.G5MovieBackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class G5MovieBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
