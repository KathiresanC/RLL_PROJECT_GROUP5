package com.G5.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.G5.model.Admin;

public interface AdminRepository extends JpaRepository<Admin, Integer>{

}
