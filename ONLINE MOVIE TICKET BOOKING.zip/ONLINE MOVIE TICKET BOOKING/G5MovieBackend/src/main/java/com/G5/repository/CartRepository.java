package com.G5.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.G5.model.Cart;


public interface CartRepository extends JpaRepository<Cart, Long>{

}
