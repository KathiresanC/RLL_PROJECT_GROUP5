package com.G5.service;

public interface AdminService {
	// Method to login an admin
	public boolean AdminLogin(String emailId, String password);
}
